#include <stdio.h>
#include <string.h>
#include <zconf.h>
#include <pthread.h>
#include <json-c/json.h>
#include "argparse.h"
#include <sqlite3.h>
#include <app_timer.h>
#include <curl/curl.h>
#include "zhelpers.h"
#include "modbus-to-http-config.h"
#include "modbus-master-config.h"

const char *path = NULL;
struct mosquitto *mosq = NULL;
int midpub = 1;
int ack = 1;

void create_database();

void *zmq_context;
void *subscriber;
char buf[200];
int slave_id;
static bool running = true;
bool is_online;
sqlite3 *db;
char *err_msg = 0;

struct uci_http *http_cfg;

struct site_context{
    const char* industry;
    const char* site;
    const char* first_query;
    const char* last_query;
    const char* first_query_id;
    const char* last_query_id;
    int query_count;
    int register_count;
    struct json_object* sensor_data;

};

struct site_context* site_contexts[32];
int site_count = 0;

char *sqlDataCount = "SELECT COUNT(id) FROM Modbus_Data";
char *sqlRetrieveData = "SELECT * FROM Modbus_Data LIMIT 5";
char *sqlInsertData = "INSERT INTO Modbus_Data(modbus_json) VALUES(?)";
sqlite3_stmt *stmt_row_count;
sqlite3_stmt *stmt_retrieve_data;
sqlite3_stmt *stmt_insert_data;

int row_count;

// Helper function for safe string duplication
char* safe_strdup(const char* str) {
    if (!str) return NULL;
    char* new_str = malloc(strlen(str) + 1);
    if (new_str) {
        strcpy(new_str, str);
    }
    return new_str;
}

int row_len() {
    int rc;
    int rowcount = 0;

    sqlite3_reset(stmt_row_count);

    rc = sqlite3_step(stmt_row_count);

    if (rc == SQLITE_ROW) {
        rowcount =
            sqlite3_column_int(stmt_row_count, 0);
    } else {
        printf("Row count fetch failed\n");
    }

    return rowcount;
}

int initialize_cli_args(int argc, const char *argv[]) {
    struct argparse_option options[] = {
            OPT_HELP(),
            OPT_STRING('p', "path", &path, "Path to configuration file"),
            OPT_END()
    };
    struct argparse argparse;
    static const char *const usage[] = {
            "xnet_modbus_http [options]",
            NULL,
    };
    argparse_describe(&argparse, "\nxNet MODBUS HTTP Client.",
                      "\nAdditional description of the program after the description of the arguments.");
    argparse_init(&argparse, options, usage, 0);
    argparse_parse(&argparse, argc, argv);
    if (path != NULL)
        printf("path: %s\n", path);

}

void init_zmq() {
    zmq_context = zmq_ctx_new();
    subscriber = zmq_socket(zmq_context, ZMQ_SUB);
    zmq_connect(subscriber, "tcp://localhost:5555");
    zmq_setsockopt(subscriber, ZMQ_SUBSCRIBE, "modbus/data", 1);
}

int store_into_database(char *data) {
    int rc;
    sqlite3_bind_text(stmt_insert_data, 1, data, -1, SQLITE_TRANSIENT);
    rc = sqlite3_step(stmt_insert_data);
    sqlite3_reset(stmt_insert_data);
    sqlite3_clear_bindings(stmt_insert_data);
    return rc;
}

void send_or_store(char *data) {
    if (is_online == 0) {
        if (row_count < 1000) {
            printf("\n---storing in database---\n");
            int rc = store_into_database(data);
            if (rc == SQLITE_DONE || rc == SQLITE_OK)
                row_count++;
        }
    }
}

int http_post_data(char *post_url, char *data) {
    CURLcode res = 0;
    /* get a curl handle */
    CURL *curl;

    curl = curl_easy_init();
    if (curl) {
        /* First set the URL that is about to receive our POST. This URL can
           just as well be a https:// URL if that is what should receive the
           data. */
        curl_easy_setopt(curl, CURLOPT_URL, post_url);
        /* Now specify the POST data */
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

        // Add timeout settings
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 10L);

        /* Perform the request, res will get the return code */
        res = curl_easy_perform(curl);
        /* Check for errors */
        if (res != CURLE_OK) {
            fprintf(stderr, "curl_easy_perform() failed: %s\n",
                    curl_easy_strerror(res));
            res = 0;
        } else {
            long http_code = 0;
            curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
            if (http_code >= 200 && http_code < 300) {
                printf("Data posted successfully on %s (HTTP %ld)\n", post_url, http_code);
                res = 1;
            } else {
                printf("HTTP POST returned status %ld for URL %s\n", http_code, post_url);
                res = 0;
            }
        }

        /* always cleanup */
        curl_easy_cleanup(curl);
    }
    return res;
}

void retrieve_data_from_db(size_t timer_id, void *arg) {
    printf(" =============== inside retrieve_data_from_db ================\n");
    struct connection *context = (struct connection *) arg;

    if (!is_online) return;
    printf("\n row_count is %d\n", row_len());
    while (sqlite3_step(stmt_retrieve_data) == SQLITE_ROW) {
        char *contents = (char *) sqlite3_column_text(stmt_retrieve_data, 2);
        int res = http_post_data((char *) http_cfg->http_url, contents);
        char buf_query[100];
        snprintf(buf_query, 100, "DELETE FROM Modbus_Data WHERE ID = %d;", sqlite3_column_int(stmt_retrieve_data, 0));
        printf("Deleting data from database with id %i\n", sqlite3_column_int(stmt_retrieve_data, 0));
        sqlite3_exec(db, buf_query, 0, 0, &err_msg);
    }
    row_count = row_len();
}

uint64_t
Hal_getTimeInMs() {
    struct timeval now;
    gettimeofday(&now, NULL);
    return ((uint64_t) now.tv_sec * 1000LL) + (now.tv_usec / 1000);
}

struct json_object* make_new_data(const char* parameter, const char* unit, const char* sensor_id, const char* device_id){
    struct json_object *data = json_object_new_object();

    struct json_object* parameter_obj = json_object_new_string(parameter);
    json_object_object_add(data, "parameter", parameter_obj);

    struct json_object* value = json_object_new_double(0.0);
    json_object_object_add(data, "value", value);

    struct json_object* unit_obj= unit!=NULL ? json_object_new_string(unit) : json_object_new_string("");
    json_object_object_add(data, "unit", unit_obj);

    struct json_object* sensor_id_obj = json_object_new_string(sensor_id);
    json_object_object_add(data, "sensor_id", sensor_id_obj);

    struct json_object* device_id_obj = device_id!=NULL ? json_object_new_string(device_id):  json_object_new_string("");
    json_object_object_add(data, "deviceId", device_id_obj);

    return data;
}

struct json_object* find_sensor_data(struct site_context* query_config, const char* parameter, const char* sensor_id){
    if (!query_config || !query_config->sensor_data) return NULL;

    size_t len = json_object_array_length(query_config->sensor_data);
    if (len==0) return NULL;
    struct json_object* element;
    for(int i=0; i<len; i++){
        element = json_object_array_get_idx(query_config->sensor_data, i);
        struct json_object* obj_param = json_object_object_get(element, "parameter");
        struct json_object* obj_sensor_id = json_object_object_get(element, "sensor_id");
        if (!obj_param || !obj_sensor_id) continue;

        const char* param_str = json_object_get_string(obj_param);
        const char* sensor_id_str = json_object_get_string(obj_sensor_id);
        if (param_str && sensor_id_str &&
            strcmp(param_str, parameter)==0 && strcmp(sensor_id_str, sensor_id)==0)
            return element;
    }
    return NULL;
}

void store_data(struct site_context* query_config, const char* parameter, double value, const char* unit, const char* sensor_id, const char* device_id){
    if (!query_config || !parameter || !sensor_id) {
        printf("Warning: Invalid parameters in store_data\n");
        return;
    }

    //check if given parameter exists in the sensor data array
    struct json_object* data = find_sensor_data(query_config, parameter, sensor_id);
    if(data==NULL){
        data = make_new_data(parameter, unit, sensor_id, device_id);
        if (data && query_config->sensor_data) {
            json_object_array_add(query_config->sensor_data, data);
        }
    }
    if (data) {
        char buffer[24];
        snprintf(buffer, sizeof(buffer), "%0.2f", value);
        json_object_object_del(data, "value");
        json_object_object_add(data, "value", json_object_new_double_s(value, buffer));
    }
}

void process_data(struct site_context* query_config, char *contents)
{
    if (!query_config || !contents) {
        printf("Error: Invalid parameters in process_data\n");
        return;
    }

    struct json_object *data_json = json_tokener_parse((char *) contents);
    if (!data_json) {
        printf("Error: Failed to parse JSON data\n");
        return;
    }

    struct json_object *data_arr;
    data_arr = json_object_object_get(data_json, "data");
    if (!data_arr) {
        printf("Error: No 'data' field in JSON\n");
        json_object_put(data_json);
        return;
    }

    json_object* device_name;
    json_object_object_get_ex(data_json, "device_name", &device_name);
    const char* sensor_id = device_name ? json_object_get_string(device_name) : "unknown";

    size_t len  = json_object_array_length(data_arr);
    for (size_t cnt = 0; cnt < len; cnt++) {
        double value;
        const char* parameter;
        const char* unit;
        const char* device_id;
        struct json_object* arr_element = json_object_array_get_idx(data_arr, cnt);
        if (!arr_element) continue;

        struct json_object* obj;
        obj = json_object_object_get(arr_element, "name");
        parameter = obj ? json_object_get_string(obj) : "unknown";

        obj = json_object_object_get(arr_element, "value");
        value = obj ? json_object_get_double(obj) : 0.0;

        obj = json_object_object_get(arr_element, "unit");
        unit = obj ? json_object_get_string(obj) : "";

        obj = json_object_object_get(arr_element, "device_id");
        device_id = obj ? json_object_get_string(obj) : "";

        store_data(query_config, parameter, value, unit, sensor_id, device_id);

    }
    json_object_put(data_json);
}

char* get_json(struct site_context* query_config)
{
    if (!query_config) {
        printf("Error: NULL query_config in get_json\n");
        return NULL;
    }

    uint64_t timestamp = Hal_getTimeInMs();
    timestamp = timestamp / 1000;

    /* Create root object */
    struct json_object *root = json_object_new_object();
    if (!root) {
        return NULL;
    }

    json_object_object_add(root, "industryId",
        json_object_new_string(query_config->industry ? query_config->industry : ""));

    json_object_object_add(root, "stationId",
        json_object_new_string(query_config->site ? query_config->site : ""));

    json_object_object_add(root, "timestamp",
        json_object_new_int64(timestamp));

    struct json_object* sensor_data_http = json_object_new_array();

    size_t len = query_config->sensor_data ? json_object_array_length(query_config->sensor_data) : 0;

    for (size_t idx = 0; idx < len; idx++)
    {
        struct json_object* src_data =
            json_object_array_get_idx(query_config->sensor_data, idx);

        if (!src_data) continue;

        const char *tmp_str =
            json_object_to_json_string(src_data);

        struct json_object* data =
            json_tokener_parse(tmp_str);

        if (data) {
            json_object_object_del(data, "sensor_id");
            json_object_array_add(sensor_data_http, data);
        }
    }

    json_object_object_add(root, "params", sensor_data_http);

    /* Convert to string */
    const char* data_str =
        json_object_to_json_string(root);

    size_t payload_len = strlen(data_str);

    char* payload = malloc(payload_len + 1);
    if (payload)
        strcpy(payload, data_str);

    json_object_put(root);

    return payload;
}

void *setup_zmq_receive(void *arg) {
    bool start_processing = false;
    bool last_query_found = false;
    struct site_context* current_site_context = NULL;

    while (running) {
        char *address = s_recv(subscriber);
        if (!address) {
            s_sleep(100);
            continue;
        }

        /**    Read message contents     **/
        char *contents = s_recv(subscriber);
        if (!contents) {
            free(address);
            s_sleep(100);
            continue;
        }

        printf("Content are %s\n", contents);
        struct json_object *jobj = json_tokener_parse(contents);
        if (!jobj) {
            free(contents);
            free(address);
            s_sleep(100);
            continue;
        }

        struct json_object* query_name_obj = json_object_object_get(jobj, "query_name");
        struct json_object* query_id_obj = json_object_object_get(jobj, "query_id");

        if (!query_name_obj || !query_id_obj) {
            json_object_put(jobj);
            free(contents);
            free(address);
            s_sleep(100);
            continue;
        }

        const char* query_name = json_object_get_string(query_name_obj);
        const char* query_id = json_object_get_string(query_id_obj);

        if (!query_name || !query_id) {
            json_object_put(jobj);
            free(contents);
            free(address);
            s_sleep(100);
            continue;
        }

        struct site_context* query_config = NULL;

        for(int q=0; q < site_count; q++){
            if(!site_contexts[q]) continue;

            if(site_contexts[q]->first_query_id &&
               strcmp(site_contexts[q]->first_query_id, query_id) == 0){
                // Reset if starting a new site
                if (current_site_context != site_contexts[q]) {
                    start_processing = false;
                    last_query_found = false;
                }
                start_processing = true;
                current_site_context = site_contexts[q];
                query_config = site_contexts[q];
                printf("Starting data collection for site: %s/%s\n",
                       query_config->industry ? query_config->industry : "N/A",
                       query_config->site ? query_config->site : "N/A");
            }

            if(start_processing && current_site_context == site_contexts[q] &&
               site_contexts[q]->last_query_id &&
               strcmp(site_contexts[q]->last_query_id, query_id) == 0){
                last_query_found = true;
                query_config = site_contexts[q];
                printf("Final query received for site: %s/%s\n",
                       query_config->industry ? query_config->industry : "N/A",
                       query_config->site ? query_config->site : "N/A");
            }
        }

        if(start_processing && query_config){
            process_data(query_config, contents);

            if(last_query_found)
            {
                char *json_content = get_json(query_config);
                if(json_content) {
                    printf("Data to send is %s\n", json_content);
                    int res = http_post_data((char *) http_cfg->http_url, json_content);
                    is_online = (bool) res;

                    if(res) {
                        printf("Data posted successfully on %s\n", http_cfg->http_url);
                    } else {
                        printf("Failed to post data on %s\n", http_cfg->http_url);
                    }

                    free(json_content);

                    // Clear sensor data for next cycle
                    if (query_config->sensor_data) {
                        json_object_put(query_config->sensor_data);
                        query_config->sensor_data = json_object_new_array();
                    }
                }
                start_processing = false;
                last_query_found = false;
                current_site_context = NULL;
            }
        }

        s_sleep(2000);
        send_or_store(contents);

        free(contents);
        free(address);
        json_object_put(jobj);
    }
    return NULL;
}

void create_database() {
    int rc = sqlite3_open("modbus_to_http.db", &db);

    if (rc != SQLITE_OK) {

        fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);

    }

    char *sql = "CREATE TABLE IF NOT EXISTS Modbus_Data(Id INTEGER PRIMARY KEY,Timestamp DEFAULT CURRENT_TIMESTAMP, modbus_json TEXT);";

    sqlite3_exec(db, sql, 0, 0, &err_msg);
}

void initialize_prepared_statements() {
    int rc;
    rc = sqlite3_prepare_v2(db, sqlDataCount, -1, &stmt_row_count, NULL);
    if (rc != SQLITE_OK) {
        printf("\n Row Count Statement not prepared: %s", sqlite3_errmsg(db));
    }

    rc = sqlite3_prepare_v2(db, sqlRetrieveData, -1, &stmt_retrieve_data, NULL);
    if (rc != SQLITE_OK) {
        printf("\n Retrieve Statement not prepared: %s", sqlite3_errmsg(db));
    }

    rc = sqlite3_prepare_v2(db, sqlInsertData, -1, &stmt_insert_data, NULL);
    if (rc != SQLITE_OK) {
        printf("\n Insert Data Statement not prepared: %s", sqlite3_errmsg(db));
    }

}

struct list_head *query_head;
struct list_head *register_head;

struct query_params{
    const char* industry;
    const char* site;
    const char* first_query;
    const char* last_query;
};

int find_number_of_tokens(const char* str, char token){
    if (!str) return 0;

    size_t str_size = strlen(str);
    int count = 0;
    for(size_t i=0; i<=str_size ;i++){
        if(str[i]==token) count++;
    }
    return count;
}

struct site_context* find_site_context(struct uci_modbus_query *query_uci){
    if (!query_uci || !query_uci->name) {
        return NULL;
    }

    const char* query_name = query_uci->name;
    char* industry_id = NULL;
    char* site_id = NULL;

    if(find_number_of_tokens(query_name, '$')==2){
        char* query_name_copy = safe_strdup(query_name);
        if (query_name_copy) {
            // Tokenize to extract industry and site
            char* token = strtok(query_name_copy, "$");
            int counter = 0;
            while(token!=NULL) {
                switch(counter) {
                    case 0:
                        industry_id = safe_strdup(token);
                        break;
                    case 1:
                        site_id = safe_strdup(token);
                        break;
                    default:
                        break;
                }
                token = strtok(NULL, "$");
                counter++;
            }
            free(query_name_copy);
        }
    }

    if (!industry_id || !site_id) {
        if (industry_id) free(industry_id);
        if (site_id) free(site_id);
        return NULL;
    }

    for(int counter = 0; counter < 32 && site_contexts[counter] != NULL; counter++){
        if(site_contexts[counter]->industry && site_contexts[counter]->site &&
           strcmp(site_contexts[counter]->industry, industry_id) == 0 &&
           strcmp(site_contexts[counter]->site, site_id) == 0){
            free(industry_id);
            free(site_id);
            return site_contexts[counter];
        }
    }

    free(industry_id);
    free(site_id);
    return NULL;
}

size_t init_site_context(){
    for (int i=0; i<32; i++){
        site_contexts[i] = NULL;
    }
    site_count = 0;

    list_for_each(query_head, &lh_modbus_query) {
        struct uci_modbus_query *query_uci;
        query_uci = list_entry(query_head, struct uci_modbus_query, list);
        if (!query_uci || !query_uci->name || !query_uci->query_id) {
            continue;
        }

        struct site_context* query_config = find_site_context(query_uci);
        if(query_config==NULL){
            query_config = calloc(1, sizeof(struct site_context));
            if (!query_config) continue;

            site_contexts[site_count++] = query_config;

            // Parse industry and site from query name
            char* query_name_t = safe_strdup(query_uci->name);
            if (query_name_t) {
                char* token = strtok(query_name_t, "$");
                int counter = 0;
                while(token!=NULL) {
                    switch(counter) {
                        case 0:
                            query_config->industry = safe_strdup(token);
                            break;
                        case 1:
                            query_config->site = safe_strdup(token);
                            break;
                        default:
                            break;
                    }
                    token = strtok(NULL, "$");
                    counter++;
                }
                free(query_name_t);
            }

            query_config->first_query = safe_strdup(query_uci->name);
            query_config->first_query_id = safe_strdup(query_uci->query_id);
            query_config->last_query = safe_strdup(query_uci->name);
            query_config->last_query_id = safe_strdup(query_uci->query_id);
            query_config->query_count = 1;
            query_config->sensor_data = json_object_new_array();
        }else{
            // Free old last query strings
            if (query_config->last_query) free((void*)query_config->last_query);
            if (query_config->last_query_id) free((void*)query_config->last_query_id);

            query_config->last_query = safe_strdup(query_uci->name);
            query_config->last_query_id = safe_strdup(query_uci->query_id);
            query_config->query_count++;
        }
    }
    return site_count;
}

int init_register_count(){
    int i = 0;
    list_for_each(register_head, &lh_modbus_register) {
        struct uci_modbus_register *register_uci;
        register_uci = list_entry(register_head, struct uci_modbus_register, list);
        if (!register_uci || !register_uci->query_id) {
            continue;
        }

        list_for_each(query_head, &lh_modbus_query) {
            struct uci_modbus_query *query_uci;
            query_uci = list_entry(query_head, struct uci_modbus_query, list);
            if (!query_uci || !query_uci->query_id) {
                continue;
            }

            if(strcmp(register_uci->query_id, query_uci->query_id)==0){
                struct site_context* query_config = find_site_context(query_uci);
                if(query_config != NULL){
                    query_config->register_count++;
                }
            }
        }
    }
    return 0;
}

// Cleanup function for site contexts
void cleanup_site_contexts() {
    for (int i = 0; i < site_count && site_contexts[i]; i++) {
        if (site_contexts[i]->industry) free((void*)site_contexts[i]->industry);
        if (site_contexts[i]->site) free((void*)site_contexts[i]->site);
        if (site_contexts[i]->first_query) free((void*)site_contexts[i]->first_query);
        if (site_contexts[i]->last_query) free((void*)site_contexts[i]->last_query);
        if (site_contexts[i]->first_query_id) free((void*)site_contexts[i]->first_query_id);
        if (site_contexts[i]->last_query_id) free((void*)site_contexts[i]->last_query_id);
        if (site_contexts[i]->sensor_data) json_object_put(site_contexts[i]->sensor_data);
        free(site_contexts[i]);
    }
}

int main(int argc, const char *argv[]) {

    initialize_cli_args(argc, argv);
    modbus_to_http_init_config(path);
    modbus_master_init_config(path);

    init_zmq();
    apptimer_init();
    pthread_t tid;
    create_database();
    initialize_prepared_statements();
    row_count = row_len();
    init_site_context();
    init_register_count();
    struct list_head *http_head, *device_head;

    printf("\nDone inits \n");
    /* In windows, this will init the winsock stuff */
    curl_global_init(CURL_GLOBAL_ALL);


    list_for_each(http_head, &lh_http) {
        int rc = 0;
        http_cfg = list_entry(http_head, struct uci_http, list);
        if (!http_cfg || !http_cfg->http_url) {
            printf("Error: Invalid HTTP configuration\n");
            continue;
        }

        pthread_create(&tid, NULL, setup_zmq_receive, NULL);

        apptimer_start((unsigned int) 30000, retrieve_data_from_db,
                       TIMER_PERIODIC, NULL);

    }
    while (running) {

        sleep(1);
    }
    printf("\nEnd main after while\n");

    // Cleanup resources
    cleanup_site_contexts();

    // Close database statements
    if (stmt_row_count) sqlite3_finalize(stmt_row_count);
    if (stmt_retrieve_data) sqlite3_finalize(stmt_retrieve_data);
    if (stmt_insert_data) sqlite3_finalize(stmt_insert_data);
    if (db) sqlite3_close(db);

    return 0;
}