#include <string.h>
#include <stdlib.h>
#include <libubox/list.h>
#include "modbus-master-config.h"

/**
 * List of configurations of Modbus Device
 */
struct list_head lh_modbus_device;
/**
 * List of configurations of Modbus Query
 */
struct list_head lh_modbus_query;
/**
 * List of configurations of Modbus Registers in the query
 */
struct list_head lh_modbus_register;

static int
modbus_device_init(struct uci_map *map, void *section, struct uci_section *s) {
    struct uci_modbus_device *net = section;
    INIT_LIST_HEAD(&net->list);
    net->device_name = s->e.name;
    return 0;
}

static int
modbus_query_init(struct uci_map *map, void *section, struct uci_section *s) {
    struct uci_modbus_query *net = section;
    INIT_LIST_HEAD(&net->list);
    net->name = s->e.name;
    return 0;
}

static int
modbus_register_init(struct uci_map *map, void *section, struct uci_section *s) {
    struct uci_modbus_register *net = section;
    INIT_LIST_HEAD(&net->list);
    net->name = s->e.name;
    return 0;
}

static int
modbus_device_add(struct uci_map *map, void *section) {
    struct uci_modbus_device *net = section;
    list_add_tail(&net->list, &lh_modbus_device);

    return 0;
}

static int
modbus_query_add(struct uci_map *map, void *section) {
    struct uci_modbus_query *net = section;
    list_add_tail(&net->list, &lh_modbus_query);
    return 0;
}

static int
modbus_register_add(struct uci_map *map, void *section) {
    struct uci_modbus_register *net = section;
    list_add_tail(&net->list, &lh_modbus_register);
    return 0;
}

static struct ucimap_section_data *
modbus_device_allocate(struct uci_map *map, struct uci_sectionmap *sm, struct uci_section *s) {
    struct uci_modbus_device *p = malloc(sizeof(struct uci_modbus_device));
    if (p) {
        memset(p, 0, sizeof(struct uci_modbus_device));
    }
    return p ? &p->map : NULL;
}

static struct ucimap_section_data *
modbus_query_allocate(struct uci_map *map, struct uci_sectionmap *sm, struct uci_section *s) {
    struct uci_modbus_query *p = malloc(sizeof(struct uci_modbus_query));
    if (p) {
        memset(p, 0, sizeof(struct uci_modbus_query));
    }
    return p ? &p->map : NULL;
}

static struct ucimap_section_data *
modbus_register_allocate(struct uci_map *map, struct uci_sectionmap *sm, struct uci_section *s) {
    struct uci_modbus_register *p = malloc(sizeof(struct uci_modbus_register));
    if (p) {
        memset(p, 0, sizeof(struct uci_modbus_register));
    }
    return p ? &p->map : NULL;
}

static struct uci_optmap modbus_device_options[] = {
        {
                UCIMAP_OPTION(struct uci_modbus_device, device_name),
                .type = UCIMAP_STRING,
                .name = "conf_name"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, type),
                .type = UCIMAP_STRING,
                .name = "type"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, connection_id),
                .type = UCIMAP_STRING,
                .name = "connection_id"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, enabled),
                .type = UCIMAP_INT,
                .name = "enabled"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, serial_port),
                .type = UCIMAP_STRING,
                .name = "serial_port"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, host),
                .type = UCIMAP_STRING,
                .name = "host"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, port),
                .type = UCIMAP_INT,
                .name = "port"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, baud),
                .type = UCIMAP_INT,
                .name = "baudrate",
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, mode),
                .type = UCIMAP_STRING,
                .name = "mode"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, parity),
                .type = UCIMAP_STRING,
                .name = "parity",
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, data_bit),
                .type = UCIMAP_INT,
                .name = "databits"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, stop_bit),
                .type = UCIMAP_INT,
                .name = "stopbits"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, rts),
                .type = UCIMAP_STRING,
                .name = "rts"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, rts_delay),
                .type = UCIMAP_INT,
                .name = "rts_delay"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, byte_timeout),
                .type = UCIMAP_INT,
                .name = "byte_timeout"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_device, response_timeout),
                .type = UCIMAP_INT,
                .name = "response_timeout"
        }
};

struct uci_optmap modbus_query_options[] = {
        {
                UCIMAP_OPTION(struct uci_modbus_query, name),
                .type = UCIMAP_STRING,
                .name = "name"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_query, query_id),
                .type = UCIMAP_STRING,
                .name = "query_id"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_query, enabled),
                .type = UCIMAP_INT,
                .name = "enabled"
        },

        {
                UCIMAP_OPTION(struct uci_modbus_query, function),
                .type = UCIMAP_INT,
                .name = "function"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_query, start_address),
                .type = UCIMAP_INT,
                .name = "start_address"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_query, count),
                .type = UCIMAP_INT,
                .name = "reg_count"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_query, connection),
                .type = UCIMAP_STRING,
                .name = "connection"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_query, slave_id),
                .type = UCIMAP_INT,
                .name = "slave_id"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_query, polling_interval),
                .type = UCIMAP_INT,
                .name = "polling_interval"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_query, no_of_retries),
                .type = UCIMAP_INT,
                .name = "no_of_retries"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_query, retry_interval),
                .type = UCIMAP_INT,
                .name = "retry_interval"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_query, file_creation_interval),
                .type = UCIMAP_INT,
                .name = "file_creation_interval"
        }

};

struct uci_optmap modbus_register_options[] = {
        {
                UCIMAP_OPTION(struct uci_modbus_register, address),
                .type = UCIMAP_INT,
                .name = "address"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, name),
                .type = UCIMAP_STRING,
                .name = "name"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, query_id),
                .type = UCIMAP_STRING,
                .name = "query_id"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, register_id),
                .type = UCIMAP_STRING,
                .name = "register_id"
        },

        {
                UCIMAP_OPTION(struct uci_modbus_register, data_type),
                .type = UCIMAP_STRING,
                .name = "data_type"

        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, process_or_config),
                .type = UCIMAP_STRING,
                .name = "process_or_config"

        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, send_alarm),
                .type = UCIMAP_STRING,
                .name = "send_alarm"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, scaling_a),
                .type = UCIMAP_STRING,
                .name = "scaling_a"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, scaling_b),
                .type = UCIMAP_STRING,
                .name = "scaling_b"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, low_threashold),
                .type = UCIMAP_INT,
                .name = "low_threashold"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, hi_threashold),
                .type = UCIMAP_INT,
                .name = "hi_threashold"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, ioa),
                .type = UCIMAP_INT,
                .name = "ioa_address"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, type_id),
                .type = UCIMAP_INT,
                .name = "ioa_type"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, index),
                .type = UCIMAP_INT,
                .name = "dnp3_index"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, class_),
                .type = UCIMAP_STRING,
                .name = "dnp3_class"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, svariation),
                .type = UCIMAP_STRING,
                .name = "dnp3_static_variation"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, evariation),
                .type = UCIMAP_STRING,
                .name = "dnp3_event_variation"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, dnp3_deadband),
                .type = UCIMAP_INT,
                .name = "dnp3_deadband"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, notification_type),
                .type = UCIMAP_STRING,
                .name = "notification_type"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, notification_recipient),
                .type = UCIMAP_STRING,
                .name = "notification_recipient"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, unit),
                .type = UCIMAP_STRING,
                .name = "unit"
        },
        {
                UCIMAP_OPTION(struct uci_modbus_register, device_id),
                .type = UCIMAP_STRING,
                .name = "device_id"
        }
};


static struct uci_sectionmap modbus_device = {
        UCIMAP_SECTION(struct uci_modbus_device, map),
        .type = "modbus_device",
        .alloc = modbus_device_allocate,
        .init = modbus_device_init,
        .add = modbus_device_add,
        .options = &modbus_device_options[0],
        .n_options = ARRAY_SIZE(modbus_device_options),
        .options_size = sizeof(struct uci_optmap)
};

static struct uci_sectionmap modbus_query = {
        UCIMAP_SECTION(struct uci_modbus_query, map),
        .type = "modbus_query",
        .alloc = modbus_query_allocate,
        .init = modbus_query_init,
        .add = modbus_query_add,
        .options = &modbus_query_options[0],
        .n_options = ARRAY_SIZE(modbus_query_options),
        .options_size = sizeof(struct uci_optmap)
};

static struct uci_sectionmap modbus_register = {
        UCIMAP_SECTION(struct uci_modbus_register, map),
        .type = "modbus_register",
        .alloc = modbus_register_allocate,
        .init = modbus_register_init,
        .add = modbus_register_add,
        .options = &modbus_register_options[0],
        .n_options = ARRAY_SIZE(modbus_register_options),
        .options_size = sizeof(struct uci_optmap)
};

struct uci_sectionmap *modbus_ftp_smap[] = {
        &modbus_device, &modbus_query, &modbus_register
};

struct uci_map modbus_ftp_map = {
        .sections = modbus_ftp_smap,
        .n_sections = ARRAY_SIZE(modbus_ftp_smap),
};

int modbus_master_init_config(const char *config_path) {
    struct uci_context *ctx;
    struct uci_package *pkg;

    INIT_LIST_HEAD(&lh_modbus_device);
    INIT_LIST_HEAD(&lh_modbus_query);
    INIT_LIST_HEAD(&lh_modbus_register);

    ctx = uci_alloc_context();
    if (!ctx) {
        printf("Error: Failed to allocate UCI context\n");
        return 1;
    }

    if (config_path != NULL) {
        uci_set_confdir(ctx, config_path);
    }
    ucimap_init(&modbus_ftp_map);

    if (uci_load(ctx, "modbus-master", &pkg)) {
        printf("Error getting configuration file\n");
        uci_free_context(ctx);
        return 1;
    }
    ucimap_parse(&modbus_ftp_map, pkg);

    uci_free_context(ctx);
    return 0;
}