#include <ucimap.h>
#include <libubox/list.h>

#ifndef MODBUS_MASTER_CONFIG_H
#define MODBUS_MASTER_CONFIG_H
/**
 * List of configurations of Modbus Device
 */
extern struct list_head lh_modbus_device;
/**
 * List of configurations of Modbus Query
 */
extern struct list_head lh_modbus_query;
/**
 * List of configurations of Modbus Registers in the query
 */
extern struct list_head lh_modbus_register;

/*
 * Initialize the configuration by reading the configuration file
 * from given path
 */
int modbus_master_init_config(const char *config_path);

/*
 * Structure for Modbus device configuration
 * This supports Modbus TCP and RTU both.
 * ASCII is not supported.
 */
struct uci_modbus_device {
    struct ucimap_section_data map;
    struct list_head list;

    const char *device_name;
    const char *type;
    const char *host;
    int port;
    int enabled;
    const char *connection_id;
    const char *serial_port;
    int baud;
    int data_bit;
    int stop_bit;
    char *mode;
    const char *rts;
    int rts_delay;
    int byte_timeout;
    int response_timeout;
    const char *parity;
    int counter;
};

/*
 * Structure for MQTT Upstream configuration
 */
struct uci_modbus_query {
    struct ucimap_section_data map;
    struct list_head list;

    const char *name;
    int function;
    int start_address;
    int count;
    const char *connection;
    const char *query_id;
    int enabled;
    int slave_id;
    int polling_interval;
    int no_of_retries;
    int retry_interval;
    int resp_count;
    int req_count;
    int reconnect_count;
    int data_error_count;
    int file_creation_interval;
};

/*
 * Structure for Modbus register configuration
 */
struct uci_modbus_register {
    struct ucimap_section_data map;
    struct list_head list;

    const char *name;
    const char *query_id;
    const char *register_id;
    int address;
    const char *data_type;
    const char *scaling_a;
    const char *scaling_b;
    const char *process_or_config;
    int hi_threashold;
    int low_threashold;
    const char *send_alarm;
    int ioa;
    int type_id;
    int index;
    const char *class_;
    const char *svariation;
    const char *evariation;
    int dnp3_deadband;
    double value;
    const char *notification_type;
    const char *notification_recipient;
    const char *alarm_status;
    const char *alarm_prev_status;
    int is_mssg_sent;
    const char *unit;
    const char *device_id;
};
#endif
