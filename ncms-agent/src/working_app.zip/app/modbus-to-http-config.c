#include <string.h>
#include <stdlib.h>
#include <libubox/list.h>
#include "modbus-to-http-config.h"

struct list_head lh_http;

static int modbus_init_http(struct uci_map *map, void *section, struct uci_section *s) {
    struct uci_http *http = section;
    INIT_LIST_HEAD(&http->list);
    http->name = s->e.name;
    return 0;
}

static int
http_config_add(struct uci_map *map, void *section) {
    struct uci_http *net = section;
    list_add_tail(&net->list, &lh_http);
    return 0;
}

static struct ucimap_section_data *
modbus_allocate_http(struct uci_map *map, struct uci_sectionmap *sm, struct uci_section *s) {
    struct uci_http *p = malloc(sizeof(struct uci_http));
    if (p) {
        memset(p, 0, sizeof(struct uci_http));
    }
    return p ? &p->map : NULL;
}

static struct uci_optmap modbus_http_options[] = {
        {UCIMAP_OPTION(struct uci_http, http_url), .type = UCIMAP_STRING,
                .name = "http_url", },
        {UCIMAP_OPTION(struct uci_http, industry_id), .type = UCIMAP_STRING,
                .name = "industry_id", },
        {UCIMAP_OPTION(struct uci_http, site_id), .type = UCIMAP_STRING,
                .name = "site_id", },
        {UCIMAP_OPTION(struct uci_http, key_param), .type = UCIMAP_STRING,
                .name = "key_param", },
        {UCIMAP_OPTION(struct uci_http, key_value), .type = UCIMAP_STRING,
                .name = "key_value", }
};

static struct uci_sectionmap http_config = {
        UCIMAP_SECTION(struct uci_http, map),
        .type = "modbus_http",
        .alloc = modbus_allocate_http,
        .init = modbus_init_http,
        .add = http_config_add,
        .options = &modbus_http_options[0],
        .n_options = ARRAY_SIZE(modbus_http_options),
        .options_size = sizeof(struct uci_optmap)
};

struct uci_sectionmap *http_smap[] = {
        &http_config
};

struct uci_map modbus_map = {
        .sections = http_smap,
        .n_sections = ARRAY_SIZE(http_smap),
};

int init_config(const char *config_path, const char * name) {
    struct uci_context *ctx;
    struct uci_package *pkg;
    INIT_LIST_HEAD(&lh_http);
    ctx = uci_alloc_context();
    if (!ctx) {
        printf("Error: Failed to allocate UCI context\n");
        return 1;
    }

    if (config_path != NULL) {
        uci_set_confdir(ctx, config_path);
    }
    ucimap_init(&modbus_map);
    if (uci_load(ctx, "modbus-to-http", &pkg)) {
        printf("Error getting configuration file");
        uci_free_context(ctx);
        return 1;
    }
    ucimap_parse(&modbus_map, pkg);

    uci_free_context(ctx);
    return 0;
}

int modbus_to_http_init_config(const char *config_path) {
    struct uci_context *ctx;
    struct uci_package *pkg;
    INIT_LIST_HEAD(&lh_http);
    ctx = uci_alloc_context();
    if (!ctx) {
        printf("Error: Failed to allocate UCI context\n");
        return 1;
    }

    if (config_path != NULL) {
        uci_set_confdir(ctx, config_path);
    }
    ucimap_init(&modbus_map);
    if (uci_load(ctx, "modbus-to-http", &pkg)) {
        printf("Error getting configuration file");
        uci_free_context(ctx);
        return 1;
    }
    ucimap_parse(&modbus_map, pkg);

    uci_free_context(ctx);
    return 0;
}