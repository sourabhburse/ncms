#include <ucimap.h>
#include <libubox/list.h>

#ifndef MODBUS_TO_HTTP_CONFIG_H
#define MODBUS_TO_HTTP_CONFIG_H

/**
 * List of configurations of MQTT upstream configurations
 */
extern struct list_head lh_http;

/*
 * Initialize the configuration by reading the configuration file
 * from given path
 */
int modbus_to_http_init_config(const char *config_path);

/*
 * Structure for HTTP Configuration
 */
struct uci_http {
    struct ucimap_section_data map;
    struct list_head list;

    const char *conection_type;
    const char *name;
    const char *http_url;
    const char *site_id;
    const char *industry_id;
    const char *key_param;
    const char *key_value;
};
#endif